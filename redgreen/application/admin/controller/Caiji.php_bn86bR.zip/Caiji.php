<?php

namespace app\admin\controller;
use app\admin\model\Admin;
use app\common\model\Users;
use think\Config;
use think\Controller;
use app\admin\model\Bet;
use app\admin\model\Caidata as CaidataModel;
use app\common\controller\Backend;
use think\Db;
use think\exception\PDOException;
use think\exception\ValidateException;

/**
 * 
 *
 * @icon fa fa-circle-o
 */
class Caiji extends Controller
{
    
    /**
     * Caidata模型对象
     * @var \app\admin\model\Caidata
     */
    protected $model = null;
    protected $site = null;
    protected $period = [1 => 1440, 3 => 480, 5 => 288];

    public function _initialize()
    {
        parent::_initialize();

        $this->model = new \app\admin\model\Caidata;
        $this->site = Config::get('site');;
//        $this->view->assign("statusList", $this->model->getStatusList());
    }
    public function index(){
//        die;
        echo '采集和结算<br>';
        //添加新的一期用于竞猜

        $this->add_next_cai();
        $this->caiji();
//        shuaxin(6);

    }


    /*
     * 采集本期
     */
    function caiji(){
        $site = $this->site;
        //需要配置
        /*
          3分钟1期，2分钟30秒订购，30秒显示彩票结果。它全天开放。交易总数为480期。
            如果您花费100积分进行交易，则在扣除2信用服务费后，您的合同金额为98信用
         */
        $where=[
            'status'=>0,
            'starttime'=>['<=',date('Y-m-d H:i:s')]
        ];
        $caidata=$this->model->where($where)->order('qishu','desc')->select();

         if (!$caidata){
            echo '没有需要采集的期数<br>';return;
        }

         foreach ($caidata as $v){
             $qishu=$v->qishu;
             // b.开始采集

             if ($v->status==0 && time()>=strtotime($v->starttime)){//到达开奖时间
//                 dump($v->id);
                 // b.开始caiji
//            b1.更改caidata的状态
                 $data=[];
                 $data['status']=1;
                 $data['result']=$v->result;
                 if (!$v->result||$v->result==''){//没有直接预设

                    //判断预设表
                     $yushe=\app\admin\model\Yushe::get(['qishu'=>$qishu]);
                     if ($yushe){
                         $data['result']=$yushe->result;
                     }
                     else{
                         //所有投注
                         $betarr=Bet::where(['qishu'=>$qishu])->select();
                         if ($site['kong']=='1'&& $betarr){//控杀已开启 且 有人下注
                             $zz_ying=-100;//最终盈利
                             $result=[0,1,2,3,4,5,6,7,8,9];
                             shuffle($result);//随机顺序进行控杀
                             foreach ($result as $k2=>$v2){
                                 $zongying= $this->yingli($qishu,$v2);
                                 $data['result']=$v2;
                                 if ($zongying>0){
                                     // $zz_ying=$zongying;
                                     break;
//                                     continue;
                                 }
//                                 if ($zongying>$zz_ying){
//                                     $zz_ying=$zongying;
//                                     $data['result']=$v2;
//                                 }
                             }

                         }else{
                             $data['result']=rand(0,9);//随机
                         }
                     }


                 }

                 $up=$this->model->update($data,['id'=>$v->id]);
                 if ($up){
                     echo '已采集'.$qishu.'开奖结果为'.$data['result'].'<br>';
                     $this->jieshuan($qishu);
                 }
                // $caidata=$this->model->get(['qishu'=>$qishu]);
             }
         }
    }
    //
    function buqi(){
        $qishu = $this->request->request('qishu');
        if (!$qishu){
            echo 'meiyou';die;
        }
        $caidata=CaidataModel::get(['qishu'=>$qishu]);
        if (!$caidata){
            echo '其数不对';die;
        }
        $this->jieshuan($qishu);
    }
    /*
     * 根据开奖结果进行结算
     */
    function jieshuan($qishu=''){
        $site = Config::get('site');
//        echo '结算逻辑未写-----<br>';die;

        if ($qishu==null||$qishu==''){//结算当前投注的
            $qishu=$this->model->where('status','1')->order('qishu','desc')->value();
        }

        //所有投注
        $betarr=Bet::where(['qishu'=>$qishu,'status'=>0])->select();
//        $betarr=Bet::where(['qishu'=>$qishu])->select();
        $caidata=CaidataModel::get(['qishu'=>$qishu]);
         $result=$caidata->result;//开奖结果

            //循环结算
        foreach ($betarr as $k=>$v){

            $yings=$v->result;//这单输赢；
            $ying=$v->result;
            $money=$v->money*(1-0.02);//这单下注金额(需要扣除信用服务费（2%）)；

            switch ($v->bet_code) {
                case 'green'://绿色
                    if(in_array($result,array('1','3','7','9'))){
                        $ying=$money*$site['green1379'];//中奖金额=（下注有效金额*赔率）
                    }elseif($result==5){
                        $ying=$money*$site['green5'];
                    }
                    break;
                case 'violet'://紫色
                    if(in_array($result,['0','5'])){
                        $ying=$money*$site['violet05'];
                    }
                    break;
                case 'red'://红色
                    if(in_array($result,array('2','4','6','8'))){
                        $ying=$money*$site['red2468'];//中奖金额=下注金额*赔率
                    }elseif($result==0){
                        $ying=$money*$site['red0'];
                    }
                    break;
                default://下注0-9
                    if (in_array($v->bet_code,['0','1','2','3','4','5','6','7','8','9','0'])){
                        if ($v->bet_code==$result){
                            $ying=$money*$site['number0-9'];
                        }

                    }
            }
            if ($ying>0){
                $yings+=$ying;//中奖金额-下注金额=输赢金额
            }

            Db::startTrans();//事务开始
            try {

                //1.添加用户金额 添加金额明细记录
                if ($ying>0){

                    Users::money($yings+$v->money,$v->users_id,"第{$v->qishu}期,下注{$v->bet_code}获奖");
                    echo "用户id:{$v->users_id}第{$v->qishu}期,下注{$v->bet_code}获奖<br>";
                }

                //2.修改注单结果和输赢金额
                $update=[
                    'status'=>1,
                    'result'=>$yings,
                    'clearingtime'=>time(),
                ];
                Bet::where('id',$v->id)->Update($update);

                //3.会员返水（在下注做）


                //4.代理占成
                //a.找到该用户的代理
                //找到该用户所有占成的上级代理，并列出占成比率
                $adminModel=new Admin();
                $zc_arr=$adminModel->zc_daili_arr($v->users_id);
                foreach ($zc_arr as $vv){
//                    $yxmoney=$ying;//有效金额（用户输的也需要扣除2%）
//                    $money;//本次下注金额
//                    $ying=
                    if ($ying>0){//用户中奖，后台减少值的公式（）
                        $ying= ($ying-$money)*-1;//（中奖金额-下注有效金额）*-1
                    }else{//用户没中奖，后台增加的公式
                        $ying=$money;
                    }

                    $zc_money=($vv['zhancheng']/100)*$ying;
                    $adminModel->money($zc_money,$vv['admin_id'],"用户id:{$v->users_id}第{$v->qishu}期,下注占成{$vv['zhancheng']}%");
                }

                //5,代理返水（在下注做）

                Db::commit();


            } catch (ValidateException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (PDOException $e) {
                Db::rollback();
                $this->error($e->getMessage());
            } catch (Exception $e) {
                Db::rollback();
                $this->error($e->getMessage());
            }
        }
        //3.本期开奖状态-已结算
        $caidata->save(['status'=>3]);
    }

    //控杀测试
    function kong(){
        $qishu='20201019456';
        $qishu='20201025431';
        $zz_ying=0;//最终盈利
        $result=[0,1,2,3,4,5,6,7,8,9];
        shuffle($result);//随机顺序进行控杀
        foreach ($result as $k2=>$v2){
            $zongying= $this->yingli2($qishu,$v2);
            echo "开奖：{$v2} 盈利：{$zongying}<br>";
            $result=$v2;
            $zz_ying=$zongying;
            dump($zongying>0);
            if ($zongying>0){
               break;
            }
        }
        echo "最终开奖：{$result} 盈利：{$zz_ying}<br>";

    }
    /*
     * 计算某种开奖盈利金额
     */
    function yingli($qishu='',$result='0'){
        $site = Config::get('site');

        if ($qishu==null||$qishu==''){//结算当前投注的
            $qishu=$this->model->where('status','1')->order('qishu','desc')->value();
        }

        //所有投注
        $betarr=Bet::where(['qishu'=>$qishu,'status'=>0])->select();
//        $caidata=CaidataModel::get(['qishu'=>$qishu]);
//        $result;//开奖结果
        $zongying=0;//玩家盈利总数
        //循环结算
        foreach ($betarr as $k=>$v){

            $ying=$v->money*-1;//这单输赢；
            $money=$v->money*(1-0.02);//这单下注金额(需要扣除信用服务费（2%）)；
            switch ($v->bet_code) {
                case 'green'://绿色
                    if(in_array($result,array('1','3','7','9'))){
                        $ying+=$money*$site['green1379'];//中奖金额=下注金额*赔率
                    }elseif($result==5){
                        $ying+=$money*$site['green5'];
                    }
                    break;
                case 'violet'://紫色
                    if(in_array($result,['0','5'])){
                        $ying+=$money*$site['violet05'];
                    }
                    break;
                case 'red'://红色
                    if(in_array($result,array('2','4','6','8'))){
                        $ying+=$money*$site['red2468'];//中奖金额=下注金额*赔率
                    }elseif($result==0){
                        $ying+=$money*$site['red0'];
                    }
                    break;
                default://下注0-9
                    if (in_array($v->bet_code,['0','1','2','3','4','5','6','7','8','9','0'])){
                        if ($v->bet_code==$result){
                            $ying+=$money*$site['number0-9'];
                        }
                    }
            }
            $zongying+=$ying;
        }
        return $zongying*-1;
    }
    /*
    * 计算某种开奖盈利金额
    */
    function yingli2($qishu='',$result='0'){
        $site = Config::get('site');

        if ($qishu==null||$qishu==''){//结算当前投注的
            $qishu=$this->model->where('status','1')->order('qishu','desc')->value();
        }

        //所有投注
        $betarr=Bet::where(['qishu'=>$qishu])->select();
//        $caidata=CaidataModel::get(['qishu'=>$qishu]);
//        $result;//开奖结果
        $zongying=0;//玩家盈利总数
        //循环结算
        foreach ($betarr as $k=>$v){

            $ying=$v->money*-1;//这单输赢；
            $money=$v->money*(1-0.02);//这单下注金额(需要扣除信用服务费（2%）)；
            switch ($v->bet_code) {
                case 'green'://绿色
                    if(in_array($result,array('1','3','7','9'))){
                        $ying+=$money*$site['green1379'];//中奖金额=下注金额*赔率
                    }elseif($result==5){
                        $ying+=$money*$site['green5'];
                    }
                    break;
                case 'violet'://紫色
                    if(in_array($result,['0','5'])){
                        $ying+=$money*$site['violet05'];
                    }
                    break;
                case 'red'://红色
                    if(in_array($result,array('2','4','6','8'))){
                        $ying+=$money*$site['red2468'];//中奖金额=下注金额*赔率
                    }elseif($result==0){
                        $ying+=$money*$site['red0'];
                    }
                    break;
                default://下注0-9
                    if (in_array($v->bet_code,['0','1','2','3','4','5','6','7','8','9','0'])){
                        if ($v->bet_code==$result){
                            $ying+=$money*$site['number0-9'];
                        }
                    }
                    dump($ying);
            }

            $zongying+=$ying;
        }
        return $zongying*-1;
    }

    /*
     * 添加新的一期
     */
    function add_next_cai(){
        $site = Config::get('site');
        $dqishu=$this->getqishu();
        $qishu=$dqishu+1;
        $qishu=str_pad($qishu,3,"0",STR_PAD_LEFT);//补零
        $qishu=date('Ymd').$qishu;
        $starttime=strtotime(date('Y-m-d'))+($site['interval']*($dqishu+1)); //开奖时间

        $next_qishu=$qishu+1;
        if($dqishu==480){
            $next_qishu=date('Ymd').'001';
        }

        $caidata=$this->model->get(['qishu'=>$qishu]);

        if (!$caidata){//不存在 开始添加
            $insert=[
                'qishu'=>$qishu,
                'result'=>null,
                'status'=>0,
                'starttime'=>date('Y-m-d H:i:s',$starttime),
                'next_qishu'=>$next_qishu,
                'next_time'=>date('Y-m-d H:i:s',$starttime+$site['interval']),
            ];
            $add=$this->model->save($insert);
            if ($add){
                echo '生成期数'.$qishu.'<br>';
            }
        }else{
            echo '已有'.$qishu.'<br>';
        }
    }
    /*
     * 获取今天已经到第几期
     */
    function getqishu(){
        $site = $this->site;
        $dtime=time()-strtotime(date('Y-m-d'));//今天过去了多久
        $dqishu=$dtime/$site['interval'];//已经过去多少期
        $qishu=(int)$dqishu;
        return $qishu;
    }

}
