const s="/h5/assets/img_gold-2a0f8277.png";export{s as i};
