import{B as t,A as s}from"./index-cfd015a1.js";function r(n){const e=t();e&&s(e.proxy,n)}export{r as u};
